% Adaptive Filtering
clear all; close all;

% Task (AIC, ANC) and algorithm selection (LMS, NLMS, RLS)
isig = 2; % 1=synthetic or 2=real signal
itask = 2; % 1=adaptive interference canceling

% 2=adaptive signal de-noising using linear prediction method
ialg = 1; % adaptation algorithm: 1=LMS, 2=NLMS (normalized LMS), 3=RLS

% LMS filter (Least Mean Squares)
M = 10; % number of adaptive filter coefficients (weights)
mi = 0.1; % adaptation speed coefficient ( 0<mi<1) i.e. m = 4 -> unstable filter

% NLMS filter (normalized LMS), faster convergence
gamma = 0.001; % not divide by zero constant e.g. = 0.001

% RLS filter (recursive LS) - more-complex, faster convergence
lambd = 0.999; % RLS - forgetting factor for Least-Squares cost function
Rinv = 0.5*eye(M,M); % RLS - inverse of Rxx matrix

% TEST SIGNALS
if(isig == 1) % SYNTHETIC SIGNALS =========================================
% Generation of an LFM/SFM test signal (linear/sinusoidal frequency modulation)
env = 1; % choose information signal envelope:
% 0=rectangular, 1=alfa*t, 2=exp(-alfa*t), 3=Gauss,
fs = 1000; % sampling frequency
Nx = 1*fs; % number of samples
A = 1; % signal amplitude
f0 = 0; % LFM: initial signal frequency
df = 100; % LFM: frequency increase [Hz/s] - lineary, SFM: modulation depth [Hz] - sinusoidally
fc = 200; % SFM: carrier frequency
fm = 1; % SFM: modulating frequency
f=0:fs/500:fs/2; % frequencies for plots
dt=1/fs; t=0:dt:(Nx-1)*dt; % time points for plots
[m,fs] = audioread('DISTURBANCE.wav');  m=m'; % LFM SIGNAL
%s = A*cos( 2*pi* (fc*t + df/(2*pi*fm)*cos(2*pi*fm*t) ); % SFM SIGNAL

% ENVELOPE choice:
if (env==0) w = boxcar(Nx)'; end % 0 = rectangular
if (env==1) alfa=5; w=alfa*t; end % 1 = alfa*t
if (env==2) alfa=5; w=exp(-alfa*t); end % 2 = exp(-alfa*t)
if (env==3) alfa=10; w=exp(-alfa*pi*(t-0.5).^2); end % 3 = Gauss
s = s .* w; % SIGNAL WITH ENVELOPE
if (itask==1) % TEST 1 - interference canceling
P = 0; % no prediction
x = 0.1*sin(2*pi*200*t-pi/5); % interference delayed and attenuated
d = s + 0.5*sin(2*pi*200*t); % signal + interference
end
if (itask==2) % TEST 2 - de-noising by prediction
P = 1; % prediction order set to 1,2,3,...)
x = m + 0.25*randn(1,Nx); % signal + noise
d = [ x(1+P:length(x)) 0 ]; % d = signal x speed-up by P samples (earlier)
end

else % REAL SIGNALS =======================================================
[m,fs] = audioread('DISTURBANCE.wav');  m=m';
sound(m,fs)
P = 1; % delay in samples
if(itask==1) % TEST 1
s = sA; % reference for comparison
x = sB; Nx = length(x); % original echo signal
d = sA + 0.25*[ zeros(1,P) sB(1:end-P) ]; % added echo copy:
end % weaker (0.25), delayed (P)
if(itask==2) % TEST 2
x = m; Nx = length(x); % original noisy speech
d = [ x(1+P:length(x)) zeros(1,P) ]; % signal x speed-up by P samples
end
f=0:fs/500:fs/2; % frequencies for plots
dt = 1/fs; t = dt*(0:Nx-1); % time for plots
h = [ 0, 0.75, 0, 0.25 ];
a = [1,h];%linear prediction coefficent

%plot(f,abs(freqz(1,a,f,fs))); title('|X(f)|');
end %======================================================================
%X=freqz(1,a,f,fs);
% Figures - input signals to adaptive filter
figure;
subplot(211); plot(t,m); grid; title('IN : signal m(n)');
subplot(212); plot(t,d); grid; title('IN : signal d(n)'); xlabel('time (s)'); 

% Calculation of optimal Wiener filter and limits for mi
for k = 0 : M
rxx(k+1) = sum( x(1+k:Nx) .* x(1:Nx-k) )/(Nx-M); % auto-correlation of x(n)
rdx(k+1) = sum( d(1+k:Nx) .* x(1:Nx-k) )/(Nx-M); % cross-correlation of d(n) and x(n)
end
Rxx = toeplitz(rxx,rxx); % symmetrical autocorrelation matrix of x(n)
h_opt = Rxx\rdx'; % weights of the optimal Wiener filter h_opt
lambda = eig( Rxx ); % eigenvalue decomposition of Rxx
lambda = sort(lambda,'descend'); % sorting eigenvalues
disp('Suggested values of mi')
mi1_risc = 1/lambda(1), % limit #1: inverse of max eigen-value
mi2_risc = 1/sum(lambda),  % Limit #2: inverse of sum of all eigen-values
figure;
subplot(211); stem( h_opt ); grid; title('Optimal Wiener filter h(n)');
subplot(212); stem( lambda ); grid; title('Eigenvalues of matrix Rxx');
% mi = mi2_risc/20;

% Adaptive filtration fun.
bx = zeros(M,1); % initialization of buffer for input signal x(n)
h = zeros(M,1); % initialization of filter weights (coefficients)


y = [];
e = [];
for i = 1 : length(x) % Main loop
bx = [ x(i); bx(1:M-1) ]; % put new sample of x(n) into the buffer
dest = h' * bx; % filtration of x(n) = y(n), i.e. prediction of d(n)
err = d(i) - dest; % prediction error
if (ialg==1) % LMS ########
h = h + ( 2*mi * err * bx ); % LMS - weights adaptation,s dependendent of adaptation speed coefficient
end
if (ialg==2) % NLMS (Normalized Least Mean Squared)
eng = bx * bx; % signal energy in buffer bx
h = h + ( (2*mi)/(gamma+eng) * err * bx ); % weights adaptation, dependendent of adaptation speed coefficient
end
if (ialg==3) % RLS (Recursive - least squared)
Rinv = (Rinv - Rinv*bx*bx'*Rinv/(lambd+bx'*Rinv*bx))/lambd; % new Rinv
h = h + (err * Rinv * bx ); % new weights

end
if(0) % Observation of filter weights and filter frequency response
subplot(211); stem(h); xlabel(n'); title('h(n)'); grid;
subplot(212); plot(f,abs(freqz(h,1,f,fs))); xlabel('f (Hz)');
title('|H(f)|'); grid; % pause
end
y = [y dest];
e = [e err];
end

% Figures - output signals
figure;
subplot(211); plot(t,y); grid; title('OUT : signal y(n) = dest');
subplot(212); plot(t,e); grid; title('OUT : signal e(n) = err');
xlabel('time [s]');
if (itask==1)
figure; subplot(111); plot(t,m,'r',t,e,'b'); grid; xlabel('time [s]');
title('Original (RED), filtration result (BLUE)'); 
end
figure; subplot(111); plot(1:M+1,h_opt,'ro-',1:M,h,'bx-'); grid;
title('h(n): Wiener (RED), our (BLUE)'); xlabel('n');
sound(y,fs)