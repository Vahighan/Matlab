% Adaptive Filtering
clear all; close all;

% Task (AIC, ANC) and algorithm selection (LMS, NLMS, RLS)
isig = 2; % 1=synthetic or 2=real signal
itask = 1; % 1=adaptive interference canceling

% 2=adaptive signal de-noising using linear prediction method
ialg = 3; % adaptation algorithm: 1=LMS, 2=NLMS (normalized LMS), 3=RLS

% LMS filter (Least Mean Squares)
M = 50; % number of adaptive filter coefficients (weights)
mi = 0.1; % adaptation speed coefficient ( 0<mi<1) i.e. m = 4 -> unstable filter

% NLMS filter (normalized LMS), faster convergence
gamma = 0.001; % not divide by zero constant e.g. = 0.001

% RLS filter (recursive LS) - more-complex, faster convergence
lambd = 0.999; % RLS - forgetting factor for Least-Squares cost function
Rinv = 0.5*eye(M,M); % RLS - inverse of Rxx matrix

[m,fs] = audioread('RECORDIN1.wav'); 
samples = [1,length(m)];
[p,fs2] = audioread('DISTURBANCE.wav',samples);

% Play input sounds
sound(m,fs)
pause(3)
sound(p,fs)

x1 = m + p;                                              % mixture of two sounds

f = 0:1:0.5*fs;

Nx = length(x1);                                         % get number of samples,
n = 0:Nx-1;                                        
dt = 1/fs;                                              % calculate sampling period
t = dt*n;                                               % calculate time stamps

sound(x1,fs)


h = [ 0, 0.75, 0, 0.25 ];
x = p;
d = m + filter(h,1,p);

% Figures - input signals to adaptive filter
figure;
subplot(211); plot(t,x); grid; title('IN : signal x(n)');
subplot(212); plot(t,d); grid; title('IN : signal d(n)'); xlabel('time (s)'); 

% Calculation of optimal Wiener filter and limits for mi
for k = 0 : M
rxx(k+1) = sum( x(1+k:Nx) .* x(1:Nx-k) )/(Nx-M); % auto-correlation of x(n)
rdx(k+1) = sum( d(1+k:Nx) .* x(1:Nx-k) )/(Nx-M); % cross-correlation of d(n) and x(n)
end
Rxx = toeplitz(rxx,rxx); % symmetrical autocorrelation matrix of x(n)
h_opt = Rxx\rdx'; % weights of the optimal Wiener filter h_opt
lambda = eig( Rxx ); % eigenvalue decomposition of Rxx
lambda = sort(lambda,'descend'); % sorting eigenvalues
disp('Suggested values of mi')
mi1_risc = 1/lambda(1), % limit #1: inverse of max eigen-value
mi2_risc = 1/sum(lambda),  % Limit #2: inverse of sum of all eigen-values
figure;
subplot(211); stem( h_opt ); grid; title('Optimal Wiener filter h(n)');
subplot(212); stem( lambda ); grid; title('Eigenvalues of matrix Rxx');
% mi = mi2_risc/20;

% Adaptive filtration fun.
bx = zeros(M,1); % initialization of buffer for input signal x(n)
h = zeros(M,1); % initialization of filter weights (coefficients)
y = [];
e = [];
for i = 1 : length(x) % Main loop
bx = [ x(i); bx(1:M-1) ]; % put new sample of x(n) into the buffer
dest = h' * bx; % filtration of x(n) = y(n), i.e. prediction of d(n)
err = d(i) - dest; % prediction error
if (ialg==1) % LMS ########
h = h + ( 2*mi * err * bx ); % LMS - weights adaptation,s dependendent of adaptation speed coefficient
end
if (ialg==2) % NLMS (Normalized Least Mean Squared)
eng = bx * bx; % signal energy in buffer bx
h = h + ( (2*mi)/(gamma+eng) * err * bx ); % weights adaptation, dependendent of adaptation speed coefficient
end
if (ialg==3) % RLS (Recursive - least squared)
Rinv = (Rinv - Rinv*bx*bx'*Rinv/(lambd+bx'*Rinv*bx))/lambd; % new Rinv
h = h + (err * Rinv * bx ); % new weights

end
%if(0) % Observation of filter weights and filter frequency response
%subplot(211); stem(h); xlabel(n'); title('h(n)'); grid;
%subplot(212); plot(f,abs(freqz(h,1,f,fs))); xlabel('f (Hz)');
%title('|H(f)|'); grid; % pause
%end
y = [y dest];
e = [e err];
end

% Figures - output signals
figure;
subplot(211); plot(t,y); grid; title('OUT : signal y(n) = dest');
subplot(212); plot(t,e); grid; title('OUT : signal e(n) = err');
xlabel('time [s]');
if (itask==1)
figure; subplot(111); plot(t,m,'r',t,e,'b'); grid; xlabel('time [s]');
title('Original (RED), filtration result (BLUE)'); 
end
if (itask==2)
n=Nx/2+1:Nx;
SNR_in_dB = 10*log10( sum( s(n).^2 ) / sum( (d(n)-s(n)).^2 ) ),
SNR_out_dB = 10*log10( sum( s(n).^2 ) / sum( (s(n)-y(n)).^2 ) ),
n=1:Nx-P;
figure; subplot(111); plot(t(n),s(n),'k',t(n),d(n),'r',t(n),y(n),'b');
grid; xlabel('time (s)');
title('Reference (BLACK), Noisy (RED), Filtered (BLUE)'); 
end
figure; subplot(111); plot(1:M+1,h_opt,'ro-',1:M,h,'bx-'); grid;
title('h(n): Wiener (RED), our (BLUE)'); xlabel('n'); 