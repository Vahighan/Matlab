x = [ 0 
10 
20 
30 
40 
50 
60 
70 
80 
90 
100 

 ];
y = [0.012 
0.012 
0.013 
0.013 
0.013 
0.014 
0.014 
0.014 
0.013 
0.013 
0.013 

 ]
figure
plot(x, y, '-b');
xlabel('Thickness [mikro*m]');
ylabel('Maximum Power Point [W/cm^2]');
