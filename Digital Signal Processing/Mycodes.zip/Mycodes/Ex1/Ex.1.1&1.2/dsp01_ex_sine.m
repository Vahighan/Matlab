% dsp01_ex_sine.m
clear all; close all;

fs=8000; Nx=3*fs;                 % sampling frequency, number of samples
dt = 1/fs;                      % sampling period 
t = dt*(0:Nx-1);                % sampling times (many moments)
A1=0.5; f1=1; f2 = fs-f1; f3 = 2*fs-f1; p1=pi/4;          % sine: amplitude, frequency and phase
x1 = A1 * sin(2*pi*f1*t+p1);    % sine as a first signal component
x2 = A1 * sin(2*pi*f1*t+p1/5);
x3 = A1 * sin(2*pi*f1*t+p1/7);
x = x1+x2+x3;                         % our choice: x = x1, x1 + 0.123*x2 + 0.456*x3 
plot(t,x,'o-'); grid; title('Signal x(t)'); xlabel('time [s]'); ylabel('Amplitude');
sound(x,fs)