% dsp01_ex_noise.m
clear all; close all;
fs = 8000; A1=0.5;
Nx = 3*fs;f1=100;
x1 = A1*sin(2*pi*f1);

s1 = rand(1,Nx);    % s1 = 0.1*(2*(s1-0.5));  % uniform;  scaling to [-0.1,0.1]
s2 = randn(1,Nx);   % s2 = 0.1*s2;            % Gaussian; scaling to std=0.1
x=f1 +s1;

sound(x,fs)
figure
subplot(221); plot(s1,'.-'); grid; title('Uniform [0,1] noise');
subplot(222); plot(s2,'.-'); grid; title('Gaussian noise');
subplot(223); hist(s1,20); title('Histogram of uniform noise');
subplot(224); hist(s2,20); title('Histogram of Gaussian noise');