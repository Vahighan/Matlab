 close all
% Orthogonal matrix for DCT-IV orthogonal transform
N = 100; % transformation order (square matrix size)
k = (0:N-1); n=(0:N-1); % columns=functions, rows=samples
S = sqrt(2/N)*cos(pi/N*(n'+1/2)*(k+1/2)); % synthesis matrix
A = S'; % analysis matrix: conjugation+transposition of S
S*A,% checking matrix orthogonality

x1 = 10*S(:,5); % signal #1 - vertical!
x2 = 20*S(:,10); % signal #2
x3 = 30*sqrt(2/N)*cos(pi/N*(n'+1/2)*(15+1/2)); % signal #3
x4 = randn(N,1); % signal #4
x = x2; % choose x1, x2, x3, x4, x1+x2, x1+x3, x1+x4
figure; plot(x,'bo-'); title('x(n)'); grid ; % input
c = A*x; % signal analysis: finding similarity coefficients
figure; stem(c); grid ; % displaying similarity coefficients, stem(c) plots the data sequence, c, as stems that extend from a baseline along the x-axis
%c(3) = 0; % removing 3-rd signal component
y = S*c; % signal synthesis: summation of weighted elementary vectors
figure; plot(y,'bo-'); title('y(n)'); grid ; % output
error = max(abs(x-y)), % signal reconstruction error