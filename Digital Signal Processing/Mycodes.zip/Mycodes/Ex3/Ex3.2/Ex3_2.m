% Orthogonality concept - for vectors and matrices
clc; clear all; close all;
x = [ -1 1 -1 1 1 1 1 1 ]; % Vector no. 1
y = [ 1 -1 1 -1 1 1 1 1 ]; % Vector no. 2
w = [ 1 1 -1 1 1 1 1 1 ]; % Vector no. 3
z = [ 1 1 1 -1 1 1 1 1 ]; % Vector no. 4
a = [ 1 1 1 1 -1 1 1 1 ]; % Vector no. 5
b = [ 1 1 1 1 1 -1 1 1 ]; % Vector no. 6
c = [ 1 1 1 1 1 1 -1 1 ]; % Vector no. 7
d = [ 1 1 1 1 1 1 1 -1 ]; % Vector no. 8

num = 4^(1/2); % default number for multiplication of vector
x1 = x*num;% multiplication of vectors 
y1 = y*num;% - by scalar 'num'
w1 = w*num;% - by scalar 'num'
z1 = z*num;% - by scalar 'num'
a1 = a*num;% - by scalar 'num'
b1 = b*num;% - by scalar 'num'
c1 = c*num;% - by scalar 'num'
d1 = d*num;% - by scalar 'num'

prod1 = sum( x1 .* conj(y1) ) % If the sum of multiplication of corresponding
prod2 = dot( x1, y1 ) % coefficients of two vectors is equal to 0,
prod3 = x1*y1' % vectors are orthogonal in Euclidean space.
A = [ x1' y1' w1' z1' a1' b1' c1' d1' ] % matrix of concateneted vectors x, y, w, z
prod4 = inv(A) * A, % product of matrix and its inverse should give I matrix
prod5 = A' * A, % inv(A)->A’ for orthogonal matrices