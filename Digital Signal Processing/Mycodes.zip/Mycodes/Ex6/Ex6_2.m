% FFT interpolation with signal windowing
clear all; close all; 
fs = 1000; % sampling ratio (Hz)
N = 100; % number of signal samples, 100 or 1000
dt=1/fs; t=dt*(0:N-1); % time scaling
K = 2; % 8,6,4,2... - interpolation order

w1 = rectwin(N); % retangular window
w2 = chebwin(N,100); % Chebyshev window
w = w2; % window choice: w1, w2, ...
%x=sin(2*pi*50*t)+0.001*sin(2*pi*175*t); % analysed signal 1
x=ones(1,N); % analysed signal 2
x = x.*w'; % signal windowing
X = fft(x,N); % without appended zeros
Xz = fft(x,K*N); % with zeros; Xz = fft([x,zeros(1,(K-1)*N)])/sum(w);
fz = fs/(K*N)*(0:K*N-1); % frequency axis
f = fs/N *(0:N-1);
figure 
%plot(f,20*log10(abs(X)/sum(w)),'bo-'),
plot(fz,20*log10(abs(Xz)/sum(w)),'r.-','MarkerFaceColor','b');
xlabel('f (Hz)'); title('Zoomed DFT via FFT [dB]'); grid; 