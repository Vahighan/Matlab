sig = 1; % 1 or 2, signal: 1=short, 2=long
if(sig==1) N=5; M=3; x = ones(1,N); h = ones(1,M); % signals to be >>  x = sin(2*pi*200*t); 
else N=256; M=32; x = randn(1,N); h = randn(1,M); % convoluted >>>>>>  h = cos(2*pi*50*t+100);
end
% Fast cross-correlation by fast convolution
R1 = xcorr( x, h ); % cross-correlation Matlab function
R2 = conv( x, conj( h(end:-1:1) ) ); % cross-correlation via convolution
Kmax=max(M,N); Kmin=min(M,N); R2 = [ zeros(1,Kmax-Kmin) R2 ];
m = -(Kmax-1) : 1 : (Kmax-1);
figure; plot(m,R1,'ro',m,R2,'bx'); title('R1(n) & R2(n)');
error5 = max( abs( R1-R2 ) ), 