fs = 4000; % sampling ratio (Hz)
T = 3; % time duration in seconds
dt=1/fs; t=dt*(0:N-1); % time scaling

sig = 1; % 1 or 2, signal: 1=short, 2=long
if(sig==1) N=5; M=3; x = sin(2*pi*200*t); h = cos(2*pi*50*t+100); % signals to be >>  x = sin(2*pi*200*t); 
else N=256; M=32; x = sin(2*pi*200*t); h = cos(2*pi*50*t+100); % convoluted >>>>>>>>  h = cos(2*pi*50*t+100);
end
n = 1:N+M-1; nn = 1:N; % sample indexes
figure;
subplot(211); stem(x); title('x(n)');
subplot(212); stem(h); title('h(n)'); 
% Conv by Matlab function
y1 = conv(x,h);
figure; stem(y1); title('y1(n)'); 
% Fast conv - WRONG!
hz = [ h zeros(1,N-M) ]; % append N-M zeros to the shorter signal only
y2 = ifft( fft(x) .* fft(hz) ); % fast conv, first M-1 samples are wrong
error2 = max(abs(y1(M:N)-y2(M:N))),
figure; 
plot(nn,y1(nn),'ro',nn,y2(nn),'bx'); title('y1(n) & y2(n)');
% Fast conv - GOOD!
hzz = [ h zeros(1,N-M) zeros(1,M-1) ]; % append zeros to the length N+M-1
xz = [ x zeros(1,M-1) ]; % append zeros to the length N+M-1
y3 = ifft( fft(xz) .* fft(hzz) ); % fast conv, all samples are good
error3 = max(abs(y1-y3)), 
figure; plot(n,y1,'ro',n,y3,'bx'); title('y1(n) & y3(n)');
% Fast conv by pieces - OVERLAP-ADD method
if( sig > 1 ) % only for long signal
L = M; % signal fragment length
K = N/L; % number of signal fragments
hzz = [ h zeros(1,L-M) zeros(1,M-1) ]; % append zeros to the shorter signal
Hzz = fft(hzz); % its FFT
y4 = zeros(1,M-1); % output signal initialization
for k = 1:K % LOOP
m = 1 + (k-1)*L : L + (k-1)*L; % select samples indexes
xz = [ x(m) zeros(1,M-1) ]; % cut signal fragment
YY = fft(xz) .* Hzz; % # fast convolution - spectra mult
yy = ifft( YY ); % # inverse FFT

y4(end-(M-2):end) = y4(end-(M-2):end) + yy(1:M-1); % output overlap-add
y4 = [ y4, yy(M:L+M-1) ]; % output append
end
error4 = max(abs(y1-y4)), 
figure; plot(n,y1,'ro',n,y4,'bx'); title('y1(n) & y4(n)');
end
