fs = 8000; % sampling ratio (Hz)
T = 3; % time duration in seconds
N = round(T*fs); % number of signal samples, 100 or 1000
dt=1/fs; t=dt*(0:N-1); % time scaling
n = 1:1000; % indexes of signal samples to observe
% Signal
x1 = sin(2*pi*200*t) + sin(2*pi*800*t); % 2xSIN
x2 = sin( 2*pi*( 0*t + 0.5*((1/T)*fs/4)*t.^2 ) ); % LFM
fm=0.5; x3 = sin(2*pi*((fs/4)*t - (fs/8)/(2*pi*fm)*cos(2*pi*fm*t))); % SFM
x = x2; % LFM signal (linear frequency modulation)
%x=x3; % SFM signal (sinusoidal frequency modulation)
figure; plot(t(n),x(n),'b-'); xlabel('t [s]'); title('x(t)'); grid; % figure
% FFT spectrum
Mwind = 256;%128,8, 512, 2048...
Mstep=16; Mfft=2*Mwind; Many = floor((N-Mwind)/Mstep)+1;

t = (Mwind/2+1/2)*dt + Mstep*dt*(0:Many-1); % time
f = fs/Mfft*(0:Mfft-1); % frequency
w = hamming( Mwind )'; % window choice
X1 = zeros(Mfft,Many); X2 = zeros(1,Mfft); % STFT, PSD initialization
for m = 1 : Many % processing loop
bx = x( 1+(m-1)*Mstep : Mwind+(m-1)*Mstep ); % signal fragment
bx = bx .* w; % windowing
X = fft( bx, Mfft )/sum(w); % FFT with scaling
X1(1:Mfft,m) = X; % STFT
X2 = X2 + abs(X).^2; % Welch PSD
%plot(f,X2); semilogy(f,X2)
end % loop end
X1 = 20*log10( abs(X1) ); % to decibels
X2 = (1/Many)*X2/fs; % PSD normalization
spectrogram(x,Mwind,Mwind-Mstep,Mfft,fs); % Matlab STFT
figure;
imagesc(t,f,X1); % amplitude spectrum matrix as an image
c=colorbar; c.Label.String = 'V (dB)'; ax = gca; ax.YDir = 'normal';
xlabel('time (s)'); ylabel('frequency (Hz)'); 
figure;
semilogy(f,X2); grid; title('Welch estimation of PSD'); xlabel('f [Hz]'); ylabel('V^2 / Hz'); 
%semilogy(f,X1);
