clear all; close all; 
fs = 1000; % sampling ratio (Hz)
N = 100; % number of signal samples, 100 or 1000
dt=1/fs; t=dt*(0:N-1); % time scaling
%A = 10; % A = 100,1000... - given amplitudes values for spectrum magnitude analysis
% Signal
w=ones(1,N);
f0=50; % f0= 50, 100, 125, 200 
x=w.*(sin(2*pi*50*t)+sin(2*pi*125*t)); % signal with frequency f0 = 50,100,125,200 Hz
figure; plot(t,x,'bo-'); xlabel('t [s]'); title('x(t)'); grid; 
% FFT spectrum
X = fft(x); % FFT
f = fs/N *(0:N-1); % frequency axis
figure; plot(f,20*log10(1/N*abs(X)*2/N),'bo-'); xlabel('f [Hz]'); title('|X(f)|'); grid; % spectrum in decibels
%plot(f,1/N*abs(X),'bo-') - spectrum linear scale
 