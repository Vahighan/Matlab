clear all; close all;
fs=8000; Nx=3*fs; % sampling frequency, number of samples
dt = 1/fs; % sampling period
t = dt*(0:Nx-1);% sampling times (many moments)
A1 = 0.5; A2 = 2.5; A3 = 10; %required different amplitudes for sine signals
x1=A1*sin(2*pi*100*t+pi/4); % 100 Hz sine signal with frequency lower than fs/2
x2=A2*sin(2*pi*500*t+pi/4);  % 500 Hz sine signal with frequency lower than fs/2
x3=A3*sin(2*pi*1000*t+pi/4);  % 1000 Hz sine signal with frequency lower than fs/2 
x = x1+x2+x3; % our choice: sum of x1,x2,x3
plot(t,x,'o-'); grid; title('Signal x(t)'); xlabel('time [s]'); ylabel('Amplitude');
sound(x,fs);