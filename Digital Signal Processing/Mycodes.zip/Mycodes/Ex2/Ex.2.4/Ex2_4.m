clear all; close all;
fs=8000; Nx=3*fs; % sampling frequency, number of samples
dt = 1/fs; % sampling period
t = dt*(0:Nx-1); % sampling times (many moments)
x1=sin(2*pi*100*t+pi/4); % 100 Hz sine signal lasting 3 seconds
x = x1; % our choice: x1
plot(t,x,'o-'); grid; title('Signal x(t)'); xlabel('time [s]'); ylabel('Amplitude');
sound(x,fs);