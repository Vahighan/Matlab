clear all; close all;
fs=1000; Nx=10*fs; % sampling frequency, number of samples
df = 200; % sampling period
dt=1/fs;
t = dt*(0:Nx-1); % sampling times (many moments)
A1=0.5; f1=1; p1=pi/4; % sine: amplitude, frequency and phase
x1=cos(2*pi*(0*t+0.5*df*t.^2)); 
x = x1; % our choice: sine with frequency increasing linearly
plot(t,x,'o-'); grid; title('Signal x(t)'); xlabel('time [s]'); ylabel('Amplitude');
sound(x,fs)
