
clear all; close all;
fs=1000; Nx=10*fs; % sampling frequency, number of samples
dt = 200; % sampling period
t = dt*(0:Nx-1); % sampling times (many moments)
A=0.5; f0=5; kA=0.25 ; mA =0.5; kF=5 ; mF=2 ; %amplitude, AM/FM depths and frequencies

x6=A*(1+kA*mA).*sin(2*pi*f0*t); % AM signal
x7=A*sin(2*pi*(f0*t+kF*cumsum(mF)*dt)); % FM signal

x=(1+0.5*x6).*x7; % joint AM-FM signal

plot(t,x,'o-'); grid; title('Signal x(t)'); xlabel('time [s]'); ylabel('Amplitude');