
clear all; close all;
% Parameters
fs = 2000; % sampling frequency (Hz)
f0=100; f1=400; f2=600; % cut-off frequencies
M = 100; % half of the filter weights - M=50, 100, 150, 200
K = 4; % oversampling order in frequency domain
N = 2*M + 1; % number of weights {b(n)} - always odd
n = -M :1: M; % non-causal weights indexes
NK = N*K; if(rem(NK,2)==1)
NK=NK+1; end % after oversampling in freq
df = fs/NK; f = df*(0 : NK/2); % frequencies

H0 = zeros(1,NK/2+1); % initialization
H1 = ones(1,NK/2+1); % initialization
% Low-Pass
ind = find( f<=f0 );
HLP = H0; HLP(ind) = ones(1,length(ind)); HLP(ind(end))=0.5;
% High-Pass
ind = find( f>=f0 );
HHP = H0; HHP(ind) = ones(1,length(ind)); HLP(ind(1))=0.5;
% Band-Pass and Band-Stop
ind1 = find( f< f1 );
ind2 = find( f<=f2 );
ind = find( ind2 > ind1(end) );
HBP = H0; HBP(ind) = ones(1,length(ind)); HBP(ind(2))=0.5; HBP(ind(end))=0.5;
HBS = H0; HBS(ind) = ones(1,length(ind)); HBS(ind(end))=0.5; HBS(ind(1))=0.5;
% Our choice: LP, HP, BP, BS
H = HBP; % choice: LP, HP, BP, BS
HLP(NK:-1:NK/2+2) = HLP(2:NK/2); % second half by symmetry
h1 = ifft( HLP ); % inverse DFT
b1 = [ h1(M+1:-1:2) h1(1:M+1) ]; % selection of 2M+1 weights

HHP(NK:-1:NK/2+2) = HHP(2:NK/2); % second half by symmetry
h2 = ifft( HHP ); % inverse DFT
b2 = [ h2(M+1:-1:2) h2(1:M+1) ]; % selection of 2M+1 weights

HBP(NK:-1:NK/2+2) = HBP(2:NK/2); % second half by symmetry
h3 = ifft( HBP ); % inverse DFT
b3 = [ h3(M+1:-1:2) h3(1:M+1) ]; % selection of 2M+1 weights

HBS(NK:-1:NK/2+2) = HBS(2:NK/2); % second half by symmetry
h4 = ifft( HBS ); % inverse DFT
b4 = [ h4(M+1:-1:2) h4(1:M+1) ]; % selection of 2M+1 weights



%b = b .* chebwin(N,100)'; % optional windowing
figure;
subplot(221); stem(n,b1); title('bLP(n)'); xlabel('n'); grid;
subplot(222); stem(n,b2); title('bHP(n)'); xlabel('n'); grid;
subplot(223); stem(n,b3); title('bBP(n)'); xlabel('n'); grid;
subplot(224); stem(n,b4); title('bBS(n)'); xlabel('n'); grid;


% Design/choice of filter coefficients b

b = [ 1 2 3 ]; % filter/polynomial weights [b0, b1, b2, b3,...]

%b = fir1(M, 100/(fs/2)); % window method: M coeffs, low-pass filter f0=100Hz
b = fir2(M,[0 75 250 fs/2]/(fs/2),[1 1 0 0]); % inverse DFT: freq->gain
%b = firls(M,[0 75 250 fs/2]/(fs/2),[1 1 0 0],[1 10]); % optimal least-squares
%b = firpm(M,[0 75 250 fs/2]/(fs/2),[1 1 0 0],[1 10]); % min of max error

figure; stem(b); title('b(k)'); xlabel('k'); grid;
% TF zeros plot
z = roots(b); % roots of nominator polynomial
figure;
var = 0 : pi/1000 : 2*pi; c=cos(var); s=sin(var);
plot(real(z),imag(z),'bo', c,s,'k-'); grid;
title('TF Zeros'); xlabel('Real()'); ylabel('Imag()'); 
% Verification of filter responses: amplitude, phase, impulse, step
f = 0 : 0.1 : 1000; % frequency in hertz
wn = 2*pi*f/fs; % normalized pulsation, radial frequency
zz = exp(-j*wn); % Z transform variable z^(-1)

H = polyval(b(end:-1:1),zz); % FR=TF for zz=exp(-j*wn): polynomial value
% H = freqz(b,1,f,fs) % all-in-one Matlab function
figure; plot(f,20*log10(abs(H))); xlabel('f [Hz]'); title('|H(f)| [dB]'); grid; 
figure; plot(f,unwrap(angle(H))); xlabel('f [Hz]'); title('angle(H(f)) [rad]'); grid; 
% Input signal x(n) - two sinusoids: 20 and 500 Hz
Nx = 2000; % number of samples
dt = 1/fs; t = dt*(0:Nx-1); % sampling times
%x = zeros(1,Nx); x(1) = 1; % Kronecker delta impulse
x = sin(2*pi*20*t+pi/3) + sin(2*pi*500*t+pi/7); % sum of 2 sines
% Digital FIR filtration: x(n) --> [ b, ] --> y(n)
M = length(b); % number of {b} coefficients
bx = zeros(1,M); % buffer for input samples x(n)
for n = 1 : Nx % MAIN LOOP
bx = [ x(n) bx(1:M-1) ]; % put new x(n) into bx buffer
y(n) = sum( bx .* b ); % do filtration, find y(n)
end %

yf = filter(b,1,x); % the same using filter()

% FIGURES: comparison of input and output
figure;
subplot(221); plot(t,x); title('x(t)'); grid; % input signal x(t)
subplot(222); plot(t,y); title('y(t)'); grid; % output signal y(t)
subplot(2,2,[3,4]); plot(t,yf); title('y(t) using filter()'); grid; % output signal y(t)

xlabel('t [s]'); 
figure; % signal spectra of the second halves of samples (transients are removed)
k=Nx/2+1:Nx; f0 = fs/(Nx/2); f=f0*(0:Nx/2-1);
subplot(211); plot(f,20*log10(abs(2*fft(x(k)))/(Nx/2))); title('|X(f)| (dB)'); grid;
subplot(212); plot(f,20*log10(abs(2*fft(y(k)))/(Nx/2))); title('|X(f)| (dB)'); grid;
xlabel('f (Hz)'); 