clear all; close all
% Orthogonal matrix for DCT-IV orthogonal transform

N = 10; % transformation order (square matrix size)
k = (0:N-1); n=(0:N-1); % columns=functions, rows=samples
S = sqrt(2/N)*cos(pi/N*(n'+1/2)*(k+1/2)); % synthesis matrix
A = sqrt(1/N)*exp(-j*2*pi/N*k'*n); % analysis matrix
S*A,  % checking matrix orthogonality
x1 = 10*S(:,5); % signal #1 - vertical!
x2 = 20*S(:,10); % signal #2
x3 = 30*sqrt(2/N)*cos(pi/N*(n'+1/2)*(15+1/2)); % signal #3
x4 = randn(N,1); % signal #4
x = x1; % choose x1, x2, x3, x4, x1+x2, x1+x3, x1+x4
prod1 = sum( n(1) .* n(2) ) % If the sum of multiplication of corresponding
prod2 = dot( n(1), n(2)) % coefficients of two vectors is equal to 0,
prod3 = n(1)*n(2)' % vectors are orthogonal in Euclidean space.
