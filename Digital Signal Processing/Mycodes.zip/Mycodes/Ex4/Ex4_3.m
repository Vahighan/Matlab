clear all; close all
% Orthogonal matrix for DCT-IV orthogonal transform
N = 10; k = (0:N-1); n=(0:N-1);
A = 1;

S = sqrt(2/N)*cos(pi/N*(n'+1/2)*(k+1/2));
S*A, 
fs=1000;dt=1/fs; t=dt*(0:N-1); T=N*dt; f0=1/T;
x1 = 10*S(:,5); % signal #1 - vertical!
x2 = 20*S(:,10); % signal #2
x3 = 30*sqrt(2/N)*cos(pi/N*(n'+1/2)*(15+1/2)); % signal #3
x4 = randn(N,1); 
x5=1*sin(2*pi*(10*f0)*t); % signal #5
x = x5; % choose x1, x2, x3, x4, x1+x2, x1+x3, x1+x4
%prod1 = sum( n(1) .* n(2) ) % If the sum of multiplication of corresponding
%prod2 = dot( n(1), n(2)) % coefficients of two vectors is equal to 0,
%prod3 = n(1)*n(2)' % vectors are orthogonal in Euclidean space.
figure; plot(x,'bo-'); title('x5'); grid; % input
c = A*x; % signal analysis: finding similarity coefficients
figure; stem(imag(c)); grid; % displaying similarity coefficients
%c(3) = 0; % removing 3-rd signal component
%y = S*c; % signal synthesis: summation of weighted elementary vectors
%figure; plot(y,'bo-'); title('y(n)'); grid; % output
%error = max(abs(x-y)), % signal reconstruction error
cs = sqrt(1/N)*c;
fk = f0*(0:N-1);
figure; subplot(211); stem(fk,real(cs)); subplot(212); stem(fk,imag(cs));
figure; subplot(211); stem(fk,abs(cs)); subplot(212); stem(fk,angle(cs));

