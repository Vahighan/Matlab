
clear all; close all
% DFT transformation matrices
N = 100; % matrix dimension
k = (0:N-1); n=(0:N-1); % rows=functions, columns=samples
A = exp(-j*2*pi/N*k'*n); % analysis matrix with different scaling
S = A'; % synthesis matrix: conjugation + transposition
% S = exp(j*2*pi/N*n’*k); A = S’; % from the lab on orthogonal transforms
 %diag(S*A), pause % checking matrix orthogonality, N on the diagonal
% Signal
fs=1000; dt=1/fs; t=dt*(0:N-1); % time scaling
T=N*dt; f0=1/T; fk = f0*(0:N-1); % frequency scaling
x1 = 1*cos(2*pi*(10*f0)*t); % signal 1   - scaling of frequency x2 distort more signal,
x2 = 1*cos(2*pi*(10.5*f0)*t); % signal 2    making it unstable (closer to natural integer number, the more stable)
x3 = 0.001*cos(2*pi*(20*f0)*t); % signal 3
x = x3; % choice: x1, x2, x3, x1+x2, x2+x3
% Window
w1 = boxcar(N)'; % rectangular pulse window
w2 = chebwin(N,100)'; % Chebyshev window - returns an N-point Chebyshev window using sidelobe FT magnitude factor (100 dB)
w = w2; scale = 1/sum(w); % choice: w1, w2 or some other window
% Windowing
x = x.*w; % signal windowing
% DFT of the signal
X1 = A*x.'; % our code
X2 = fft(x.'); % computes the discrete Fourier transform (DFT) of x using a fast Fourier transform
error1 = max(abs(X1-X2)), % error versus Matlab, should be very small
X = X2; % choice
% DFT spectrum interpretation with appropriate scaling
X = scale*X; % amplitude scaling

figure;
subplot(211); plot(fk,real(X),'o-'); title('real(X(f))');
subplot(212); plot(fk,imag(X),'o-'); title('imag(X(f))');
figure;
subplot(211); plot(fk,20*log10(abs(X)),'o-'); title('abs(X(f)) [dB]');
subplot(212); plot(fk,angle(X),'o-'); title('angle(X(f))')
% DFT spectrum modification
%X(1+10)=0; X(N-10+1)=0; % removing signal x1 with freq. 10*f0 -> y==x3 when x3 is scaled by 0.001, X(N-10+1) also scales for N=100
% Inverse DFT - signal synthesis
y = S*X; % signal reconstruction
ym = ifft(X/scale);
errorIFFT2 = max(abs(y-ym)),
figure; % output
subplot(211); plot(real(y),'bo-'); title('real(y(n))'); grid;
subplot(212); plot(imag(y),'bo-'); title('imag(y(n))'); grid;
error2 = max(abs(x-real(y))), % signal reconstruction error

