
% Speech sampled at 44.1 kHz is modulating in frequency a 7.5 kHz cosine carrier

clear all; close all;
% Parameters
K = 1; % optional K-times up-sampling ratio of 44.1 kHz signal
fc = 7500; % carrier frequency (Hz)
M = 200; N=2*M+1; % N = 2M+1 = length FIR filters (to be designed)
fmax = 4000; % maximum signal frequency of speech (Hz)
DF = 5000; % 2*DF = required bandwidth of FM modulated signal (Hz)
kf = (DF/fmax-1)*fmax; % modulation index from Carson’s rule

% Reading modulating signal

[x,fx] = audioread( 'speech44100.wav', [1,1*44100] ); % samples from-to
soundsc(x,fx); x = x'; % listen to speech
x = resample(x,K,1); fs = K*fx; % optional up-sampling
Nx = length(x); dt=1/fs; t=dt*(0:Nx-1); % variables used

% Short-Time Fourier Transform plot verification
figure;
subplot(211); plot(t,x); grid; xlabel('t (s)'); title('x(t)');
subplot(212); spectrogram(x,256,192,512,fs,'yaxis'); title('STFT(1)'); 
% FM modulation
y = cos( 2*pi*( fc*t + kf*cumsum(x)*dt ) );
figure; spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(2)'); 
% Differentiation filtering
n=-M:M; hD=cos(pi*n)./n; hD(M+1)=0; w = kaiser(2*M+1,10)'; hD = hD .* w; % filter weights
y = filter(hD, 1, y); y = y(N:end); % filtering
figure; spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(3)'); 
% Power of two
y = y.^2;
figure; spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(4)'); 
% Low-pass filtering
n=-M:M; hLP=sin(2*pi*4000/fs*n)./(pi*n); hLP(M+1)=2*(4000)/fs; hLP = hLP .* w;
y = filter(hLP, 1, y ); y = y(N:end);
figure; spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(5)'); 

% Digital Phase Shifting and Differentiation Filters

% Multiplying by 2 and square root
y = real( sqrt(2*y) );
figure; spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(6)'); 

% Final scaling
y = (y - 2*pi*fc/fs)/(2*pi*kf/fs);
figure; spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(7)'); 

% Result
t=t(2*N-1:Nx); figure;
subplot(211); plot(t,y); grid; xlabel('t (s)'); title('y(n)');
subplot(212); spectrogram(y,256,192,512,fs,'yaxis'); title('STFT(8)'); 
x = resample(y,1,K);
soundsc(x,fx); 

% Applying  Hilbert filter and analytic signal concept to the FM signal demodulation problem
xa = hilbert( x ); % filtering recorded .wav file
ang = unwrap(angle( xa )); % FM demodulation
