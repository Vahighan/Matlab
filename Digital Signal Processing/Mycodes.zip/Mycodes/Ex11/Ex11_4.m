% FIR Hilbert transform/filter AM and FM demodulator
clear all; close all;
Nx=4000; fs=8000; n=0:Nx-1; dt=1/fs; t=dt*n;
A=10; kA=0.5; fA=2; xA = A*(1 + kA*sin(2*pi*fA*t)); % AM
kF=200; % FM modulation depth kF = 300; kF = 400; kF = 500;
fF=1; xF = kF*sin(2*pi*fF*t); % FM
fc=5000; x = xA .* sin(2*pi*(fc*t + cumsum(xF)*dt)); % modulated carrier
xa = hilbert( x ); % analytic signal
xAest = abs( xa ); % AM demodulation
ang = unwrap(angle( xa )); % below FM demod
xFest = (1/(2*pi)) * (ang(3:end)-ang(1:end-2)) / (2*dt);
figure; plot(t,xA,'r-',t,xAest,'b-'); title('AM'); grid; % AM plot with blue plot of its demodulation
figure; plot(t,xF,'r-',t(2:Nx-1),xFest-fc,'b-'); title('FM'); grid; % FM plot with blue plot of its demodulation

% Design of Hilbert filter weights

% Weights h are derived mathematically
M=50; N=2*M+1; n=-M:M; h=(1-cos(pi*n))./(pi*n); h(M+1)=0;
figure; stem(n,h); title('h(n)'); xlabel('n'); grid; 

% Filter frequency response
f=-fs/2:fs/2000:fs/2;
H = freqz(h,1,f,fs);

figure; plot( f, 20*log10(abs(H)) ); title('A-F response'); grid; 
figure; plot( f, unwrap(angle(H)) ); title('P-F response'); grid; 