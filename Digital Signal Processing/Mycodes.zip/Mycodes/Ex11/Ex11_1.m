clear all; close all;

% Hilbert filter and analytic signal calculation in frequency domain

Nx=1000; fs=2000; f0=fs/40; x=cos(2*pi*(f0/fs)*(0:Nx-1));
xa1=hilbert(x);                  % Matlab function - discrete-time analytic signal using Hilbert transform of real data seq.
X=fft(x);                        % signal FFT, next its modification
Xa=fft(xa1);                     % analytic signal FFT( Xa=fft(xa2); )
n=1:Nx/2;  X(n)=-j*X(n);         % modification for positive frequencies
X(1)=0; X(Nx/2+1)=0;             %
n=Nx/2+2:Nx; X(n)= j*X(n);       % modification for negative frequencies
xH=real(ifft(X));                % inverse FFT 
xa2=x+j*xH;                      % analytic signal
err1=max(abs(xa1-xa2)),          % error vs Matlab comparison
figure; plot(1:Nx,x,'ro-',1:Nx,xH,'bo-'); grid; % signals x and xH with overlay
figure; plot(x,xH,'bo-'); grid; 
figure; for n=1:100,
plot(x(n),xH(n),'bo'); hold on; pause(0.05); end