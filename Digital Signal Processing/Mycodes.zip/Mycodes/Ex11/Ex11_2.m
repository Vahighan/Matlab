clear all; close all;

% Hilbert filter and analytic signal calculation in frequency domain

Nx=1000; fs=2000; f0=fs/40; x=cos(2*pi*(f0/fs)*(0:Nx-1));
xa1=hilbert(x);                  % Matlab function
X=fft(x);                        % signal FFT, next its modification
Xa=fft(xa1);                     % analytic signal FFT( Xa=fft(xa2); )
n=1:Nx/2;  X(n)=-j*X(n);         % modification for positive frequencies
X(1)=0; X(Nx/2+1)=0;             %
n=Nx/2+2:Nx; X(n)= j*X(n);       % modification for negative frequencies
xH=real(ifft(X));                % inverse FFT 
xa2=x+j*xH;                      % analytic signal
err1=max(abs(xa1-xa2)),          % error vs Matlab comparison
figure; plot(1:Nx,x,'ro-',1:Nx,xH,'bo-'); grid; 
figure; plot(x,xH,'bo-'); grid; 

% Design of Hilbert filter weights

% Weights h are derived mathematically
M=50; N=2*M+1; n=-M:M; h=(1-cos(pi*n))./(pi*n); h(M+1)=0;
figure; stem(n,h); title('h(n)'); xlabel('n'); grid; 
% Calculation of Kaiser window and filter weigths windowing of signal 'h'
w=kaiser(N,10)'; h = h.*w;
figure; stem(n,h); title('h(n) with no error'); xlabel('n'); grid;
% Filter frequency response
fs=2000; f=-fs/2:fs/2000:fs/2;
H1 = polyval( h(end:-1:1), exp(-j*2*pi*f/fs) ); % constant compensating multiplication 
H2 = freqz(h,1,f,fs);
figure; plot( f, 20*log10(abs(H2)) ); title('A-F response'); grid; 
figure; plot( f, unwrap(angle(H2)) ); title('P-F response'); grid; 
figure; plot( f, angle(exp(j*2*pi*f/fs*M).*H2) ); title('original response'); grid; % original frequency response of the filter is multiplied by e^−j2π(f / fs)M(due to “shift-in-time”) and therefore its phase-response is linearly decreasing
figure; plot( f, angle(exp(j*2*pi*f/fs*M).*H1) ); title('multiplied by exp(-j*2*pi*f/fs)');grid;