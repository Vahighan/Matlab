clear all; close all;
% Design/choice of filter coefficients - transfer function (TF) polynomials
if(0) % choosing polynomial coefficients
b = [1,20]; % other exemplary values [ b1, b0 ]: [4,1], [1,20]
a = [1,2,3,4nhnnnnnnnnlk;.]; % [ a3, a2, a1, a0=1]
z = roots(b); p = roots(a); % [b,a] --> [z,p]
else % choosing polynomial roots
gain = 0.001;
z = j*2*pi*[ 600,800 ]; z = [z conj(z)];
p = [-1,-1] + j*2*pi*[100,200]; p = [p conj(p)];
b = gain*poly(z); a = poly(p); % [z,p] --> [b,a]
end
figure; plot(real(z),imag(z),'bo', real(p),imag(p),'r*'); grid;
title('Zeros and Poles'); xlabel('Real()'); ylabel('Imag()'); 
% Verification of filter responses(FRs): amplitude, phase, impulse, step
f = 0 : 1 : 1000; % frequency in hertz
w = 2*pi*f; % pulsation, radial frequency
s = j*w; % Laplace transform variable
H = polyval(b,s) ./ polyval(a,s); % FR=TF for s=j*w: ratio of two polynomials
figure; plot(f,20*log10(abs(H))); xlabel('f [Hz]'); title('|H(f)| [dB]'); grid; 
figure; plot(f,unwrap(angle(H))); xlabel('f [Hz]'); title('angle(H(f)) [rad]'); grid; 
figure; impulse(b,a);  % filter response to impulse on input
figure; step(b,a); % filter response to step change on input