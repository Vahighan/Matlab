% dsp07_ex_analog_tranform.m - frequency transformation of low-pass analog filter
clear all; close all;

% Requirements
N  =  2;             % number of poles in analog prototype i.e.(N=4,8,16,64)
f0 = 100;           % for LowPass and HighPass
f1 = 10; f2=100;    % for BandPass and BandStop
Rp = 3;             % allowed oscillation in the pass-band (dB)
Rs = 100;           % allowed oscillation in the stop-band (dB)
w = 0 : 0.01 : 10;

% Design of analog LowPass prototype filters for w0 = 1 
  [z,p,gain] = buttap(N);          % analog Butterwoth prototype
% [z,p,gain] = cheb1ap(N,Rp);      % analog Chebyshev 1 prototype
% [z,p,gain] = cheb2ap(N,Rs);      % analog Chebyshev 2 prototype
% [z,p,gain] = ellipap(N,Rp,Rs);   % analog elliptic prototype
b = gain*poly(z);                  % [z,gain] --> b      
a = poly(p);                       % p --> a
H = freqs(b,a,w);                  % filter frequency response using Matlab  
fi=0:pi/1000:2*pi; c=cos(fi); s=sin(fi);
figure; plot(w,20*log10(abs(H))); grid; xlabel('w [rad*Hz]'); title('Analog Proto |H(f)|');  
figure; plot(real(z),imag(z),'ro',real(p),imag(p),'b*',c,s,'k-'); grid; title('Analog Proto ZP'); 
      
% Frequency transformation: Normalized (w0=1) LowPass --> DifferentPass
% Functions xx2yy from Signal Processing Toolbox
  %[b,a] = lp2lp(b,a,2*pi*f0);                         % LowPass to LowPass
% [b,a] = lp2hp(b,a,2*pi*f0);                         % LowPass to HighPass
 [b,a] = lp2bp(b,a,2*pi*sqrt(f1*f2),2*pi*(f2-f1));   % LowPass to BandPass
% [b,a] = lp2bs(b,a,2*pi*sqrt(f1*f2),2*pi*(f2-f1));   % LowPass to BandStop

z=roots(b); p=roots(a);
%figure; semilogx(w,20*log10(abs(H))); xlabel('f [Hz]'); title('|H(f)| [dB]'); grid;


% Verification of filter responses: amplitude, phase, impulse, step
f = 0 : 1 : 1000;                  % frequency in hertz
w = 2*pi*f;                        % pulsation, radial frequency
s = j*w;                           % Laplace transform variable
H = polyval(b,s) ./ polyval(a,s);  % FR=TF for s=j*w: ratio of two polynomials

figure; semilogx(f,20*log10(abs(H))); xlabel('f [Hz]'); title('|H(f)| [dB]'); grid; % amplitude response
figure; plot(f,unwrap(angle(H))); xlabel('f [Hz]'); title('angle(H(f)) [rad]'); grid; 
figure; impulse(b,a);              % filter response to impulse on input 
figure; step(b,a);                 % filter responset to step change on input
