% Lowpass filter for AD converter,
% working with sampling ratio 48000 sps (samples per second).

clear all; close all;
% Design/choice of filter coefficients - transfer function (TF) polynomials
if(0) % choosing polynomial coefficients i.e. if(1,2,3 ...etc.)
b = [3,2]; % other exemplary values of coefficients [ b1, b0 ]: [4,1], [1,20]...
a = [4,3,2,1]; % [ a3, a2, a1, a0=1] i.e.[-2, 2, 0, 8]...
z = roots(b); p = roots(a); % [b,a] --> [z,p]
else % choosing polynomial roots -> "if coefficient is zero, method of poles & zeroes is used"
gain = 1;
N = 5;                                   % number of TF poles
%f0 = 250000;                             % cut-off frequency of low-pass filter ->case1:f0/2>f, case2:f0/2<=f
f0=6000;                                % case2 i.e. f0 = 6000 Hz
alpha = pi/N;                            % angle 
beta  = pi/2 + alpha/2 + alpha*(0:N-1);  % angles of poles
R = 2*pi*f0;                             % circle radius
p = R*exp(j*beta);                       % poles placed on circle, left half-plane
z = []; gain = prod(-p);                 % LOW-PASS: TF zeros are not used, gain
b = gain*poly(z); a = poly(p); % [z,p] --> [b,a]
b = real(b);      a=real(a);
end
figure; plot(real(z),imag(z),'bo', real(p),imag(p),'r*'); grid;
title('Zeros and Poles'); xlabel('Real()'); ylabel('Imag()'); 
% Verification of filter responses(FRs): amplitude, phase, impulse, step
f = 0 : 1 : 48000; % frequency in hertz
w = 2*pi*f; % pulsation, radial frequency
s = j*w; % Laplace transform variable
H = polyval(b,s) ./ polyval(a,s); % FR=TF for s=j*w: ratio of two polynomials
figure; plot(f,20*log10(abs(H))); xlabel('f [Hz]'); title('|H(f)| [dB]'); grid; 
figure; plot(f,unwrap(angle(H))); xlabel('f [Hz]'); title('angle(H(f)) [rad]'); grid; 
figure; impulse(b,a);  % filter response to impulse on input
figure; step(b,a);  % filter response to step change on input