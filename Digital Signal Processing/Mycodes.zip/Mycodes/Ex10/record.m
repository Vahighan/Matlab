 
fs = 8000; % default sampling frequency (samples per second):
bits = 8; % number of bits per sample: 8, 16, 24, 32
channels = 1; % number of channels: 1 or 2 (mono/stereo)
recording = audiorecorder(fs, bits, channels); % create recording object
disp('Press any key and to record audio');  
record(recording); % start recording
pause(3); % record for two seconds
stop(recording); % stop recording
audio = getaudiodata( recording, 'single' ); % import data from the audio object 
x = audio; clear audio;

soundsc (x,fs); % play a default recorded sound

recording2 = audiorecorder(fs, bits, channels); % create recording object
disp('Press any key and to record audio');  
record(recording2); % start recording
pause(3); % record for two seconds
stop(recording2); % stop recording
audio2 = getaudiodata( recording2, 'single' ); % import data from the audio object 
y = audio2; clear audio;

soundsc (y,fs); % play a default recorded sound
%Play the mixed, up-sampled audio.
z = x + y;
soundsc (z,fs); 
 
 

