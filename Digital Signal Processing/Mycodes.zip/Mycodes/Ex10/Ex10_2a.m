
clc; clear; close all;

[m,fs] = audioread('ELECTRICGUITAR1.wav'); 
samples = [1,length(m)];
[p,fs2] = audioread('SYNTH1.wav',samples);

% Play input sounds
sound(m,fs)
pause(3)
sound(p,fs)

x = m + p;                                              % mixture of two sounds

f = 0:1:0.5*fs;

Nx = length(x);                                         % get number of samples,
n = 0:Nx-1;                                        
dt = 1/fs;                                              % calculate sampling period
t = dt*n;                                               % calculate time stamps

% Play the mixture of sounds
sound(x,fs);



