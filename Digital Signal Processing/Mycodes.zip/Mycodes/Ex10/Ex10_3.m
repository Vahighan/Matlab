%Signal down-sampling
clear all; close all;
% Input - parameters and signal x
L=4; M=50; N=2*M+1; Nx=100; % L - down-sampling ratio
x = sin(2*pi*(0:Nx-1)/50); plot(x);  % signal to be down-sampled

% [x,fs]=audioread(’music.wav’); x=x(:,1)’; Nx = length(x); % for further tests
R=rem(Nx,L); x = x(1:end-R); Nx = Nx-R; % adjusting length to polyphase filtering
% Slow down-sampling (decimation)
% Firstly, one convolution of filter weights with signal samples, then decimation
g = fir1(N-1, 1/L - 0.1*(1/L),kaiser(N,12)); % decimation filter design
y = filter(g,1,x); % filtering %also: y=decimate(x,L) or y=resample(x,1,L)
yd = y(1:L:end); % decimation
n = M+1:Nx-M; nd = (N-1)/L+1:Nx/L;
figure; plot(n,x(n),'ro-',n(1:L:end),yd(nd),'bx'); title('x(n) and yd(n)');
err1 = max(abs(x(n(1:L:end))-yd(nd))), 
% Fast polyphase down-sampling (decimation)
% L convolutions of PP components of original signal and filter weights
% samples to be removed  (not calculated!)
x = [ zeros(1,L-1) x(1:end-(L-1)) ];
ydpp = zeros(1,Nx/L);
for k=1:L
ydpp = ydpp + filter( (g(k:L:end)), 1, x(L-k+1:L:end) );
end
err2 = max(abs(yd-ydpp));