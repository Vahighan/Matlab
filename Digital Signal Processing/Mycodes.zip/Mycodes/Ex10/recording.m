clear all; load ECG100.mat; 
whos;
x=y(1,:); plot(x);
fs = 1.17 ;
N=length(x); dt=1/fs; t=dt*(0:N-1);
xup=resample(x,20,1);
soundsc(xup,8000);
