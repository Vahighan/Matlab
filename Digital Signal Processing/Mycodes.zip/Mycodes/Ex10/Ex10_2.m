% dsp10_ex_up.m - Signal up-sampling
clear all; close all;

fs_up = 48000; % up - sampling frequency 
fs = 8000; % default sampling frequency (samples per second):
bits = 8; % number of bits per sample: 8, 16, 24, 32
channels = 1; % number of channels: 1 or 2 (mono/stereo)
recording = audiorecorder(fs, bits, channels); % create recording object
disp('Press any key and to record audio');  
record(recording); % start recording
pause(3 ); % record for two seconds
stop(recording); % stop recording
audio = getaudiodata( recording, 'single' ); % import data from the audio object 
xup = audio; clear audio;
soundsc(xup,fs_up); % play a up-sampled  recorded sound
x=xup;
soundsc (x,fs); % play a default recorded sound

% Input - parameters and signal x
K=5; M=50; N=2*M+1; Nx=1000; % K - up-sampling ratio, i.e.Nx=500; Nx=100; Nx=2000;
x = sin(2*pi*(0:Nx-1)/100); % signal to be up-sampled, i.e. cos(2*pi*(0:Nx-1)/100); sin(2*pi*(0:Nx-1)/1000);
 [x,fs]=audioread('speech.wav'); x=x(:,1)'; Nx = length(x); % for further tests
R=rem(Nx,K); x = x(1:end-R); Nx = Nx-R; % adjusting length to polyphase filtering
% Slow up-sampling (interpolation)
% one convolution of filter weights with zero-inserted signal
xz = zeros(1,K*Nx); % # signal with inserted zeros
xz(1:K:end) = x; % #
h = K*fir1(N-1, 1/K, kaiser(N,12)); % interpolattion filter design
yi = filter(h,1,xz); % signal filtering
y = interp(x,K); 
% y = resample(x,K,1;
n = M+1:K:K*Nx-M; ni = N:K*Nx-(K-1);
figure; plot(n,x(M/K+1:Nx-M/K),'ro-',ni-M,yi(ni),'bx'); title('x(n) and yi(n)');
err1 = max(abs(x(M/K+1:Nx-M/K)-yi(ni(1:K:end)))), 
% Fast polyphase up-sampling (interpolation)
% K convolutions of original signal with K poly-phase filter weight sequences
% signal is not zeros-inserted
for k=1:K
yipp(k:K:K*Nx) = filter( h(k:K:end), 1, x);
end
err2 = max(abs(yi-yipp));
figure; stem(h); title('h(n)'); grid;