
clear all; close all;
p=3; N=2^p; % number of noise signal samples
x=randn(N,1); % Normally distributed random noise

X1=fft(x); % DFT of noise signal
X2=myRecFFT_1(x); % calculating DFT using recursive implementation of radix-2 DIT FFT 
err=max(abs(X1-X2)) % error between FFT and recursive functions
 
