
clear all; close all;
p=2; % input arguments of requested choice
N=2^p; % number of noise signal samples
x=randn(N,1); % Normally distributed random noise

X=myRecFFT_1(x); % sequence of functions calls
xr=myRecIFFT(X)/N;

err=max(abs(x-xr))