% Observe symmetry  of Real(X): Xr(N-k)=Xr(k), k=1,2,...,N-1;
% Observe asymmetry of Imag(X): Xi(N-k)=conj(Xi(k)), k=1,2,...,N-1; Xi(0)=X(N/2)=0;

% One-level FFT : first FFT sample re-ordering
clear all; close all;

N = 64; x = rand(1,N); % analyzed signal, N=2^p
Xm = fft(x); % its DFT (FFT)
Xe = fft(x(1:2:N)); % DFT of "even" samples
Xo = fft(x(2:2:N)); % DFT of "odd" samples
X = [ Xe, Xe ] + exp(-j*2*pi/N*(0:1:N-1)) .* [Xo, Xo ]; % combining two DFT spectra
xe=x; % assigning to even/odd-indexed signal samples
xo=x;
xee=xe(1:2:end); xeo=xe(2:2:end); %xoe=xo(1:2:end);xoo=xo(2:2:end);

figure
k = 0:N-1;
subplot(211); hold on
stem(k,real(X)); xlabel('k'); title('Real(X)');
stem(0,real(X(1)),'r','filled'); xlabel('k'); title('Real(X)');

subplot(212); hold on
stem(k,imag(X)); xlabel('k'); title('Imag(X)');
stem(0,imag(X(1)),'r','filled');
stem(N/2,imag(X(N/2+1)),'b','filled'); xlabel('k'); title('Real(X)'); 

% Exploit this symmetry
x_comb = xe + j*xo;    % Artificial complex-value signal
Xeo = fft(x_comb);     % Its DFT spectrum
Xeo_r = real(Xeo);
Xeo_i = imag(Xeo);

% Reconstruction of X from Xee
Xr(2:N) = (Xeo_r(2:N)+Xeo_r(N:-1:2))/2;  % using symmetry  of Real(X1)
Xi(2:N) = (Xeo_i(2:N)-Xeo_i(N:-1:2))/2;  % using asymmetry of Imag(X1)
Xr(1) = Xeo_r(1);
Xi(1) = 0;
X_rec = Xr + j*Xi;
error_X1 = max(abs( X - X_rec )),