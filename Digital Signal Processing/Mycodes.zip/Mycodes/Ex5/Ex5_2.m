% One-level FFT : first FFT sample re-ordering
clear all; close all;

N = 4;  % analyzed signal, N=2^p i.e. 2,4,8,16..
x1 = randn(1,N);     % Signals
x2 = randn(1,N);
x3(1:2:2*N) = x1;    x3(2:2:2*N) = x2;         % even and odd samples

X1 = fft(x1);        % Their DFT spectra
X2 = fft(x2);

 % its DFT (FFT)
Xe = fft(x1); % DFT of "even" samples
Xo = fft(x2); % DFT of "odd" samples

%X = [ Xe, Xe ] + exp(-j*2*pi/N*(0:1:N-1)) .* [Xo, Xo ]; % combining two DFT spectra
%error = max( abs( X - Xm ) ), % error

k = (0:N-1); n=(0:N-1);
Ae=exp(-j*2*pi/N*k'*n); % analysis matrix Ae
Ao=exp(-j*2*pi/N*k'*n); % analysis matrix Ao

xe=x1; % assigning to even/odd-indexed signal samples
xo=x2;
Xe=Ae*xe.'; % matrix - vector multiplication to achieve DFT vectors
Xo=Ao*xo.';
X1=fft(Xe); % calculation of new DFT spectra
X2=fft(Xo);

figure
k = 0:N-1;
subplot(211); hold on
stem(k,real(X2)); xlabel('k'); title('Real(X)');
stem(0,real(X2(1)),'r','filled'); xlabel('k'); title('Real(X)');

subplot(212); hold on
stem(k,imag(X2)); xlabel('k'); title('Imag(X)');
stem(0,imag(X2(1)),'r','filled');
stem(N/2,imag(X2(N/2+1)),'b','filled'); xlabel('k'); title('Imag(X)'); 

% Exploit this symmetry
xeo = xe + j*xo;    % Artificial complex-value signal
Xeo = fft(xeo);     % Its DFT spectrum
Xeor = real(Xeo);
Xeoi = imag(Xeo);



