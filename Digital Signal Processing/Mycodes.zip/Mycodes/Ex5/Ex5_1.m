% Observe symmetry  of Real(X): Xr(N-k)=Xr(k), k=1,2,...,N-1;
% Observe asymmetry of Imag(X): Xi(N-k)=conj(Xi(k)), k=1,2,...,N-1; Xi(0)=X(N/2)=0;

% One-level FFT : first FFT sample re-ordering
clear all; close all;

N = 2;% analyzed signal, N=2^p i.e. 2,4,8,16..

x1 = randn(1,N);     % Signals
x2 = randn(1,N);
x3(1:2:2*N) = x1;    x3(2:2:2*N) = x2;         % even and odd samples

X1 = fft(x1);        % Their DFT spectra
X2 = fft(x2);
X3 = fft(x3);

figure
k = 0:N-1;
subplot(211); hold on
stem(k,real(X1)); xlabel('k'); title('Real(X)');
stem(0,real(X1(1)),'r','filled'); xlabel('k'); title('Real(X)');

subplot(212); hold on
stem(k,imag(X1)); xlabel('k'); title('Imag(X)');
stem(0,imag(X1(1)),'r','filled');
stem(N/2,imag(X1(N/2+1)),'b','filled'); xlabel('k'); title('Imag(X)');

% Exploit this symmetry
x12 = x1 + j*x2;    % Artificial complex-value signal
X12 = fft(x12);     % Its DFT spectrum
X12r = real(X12);
X12i = imag(X12);