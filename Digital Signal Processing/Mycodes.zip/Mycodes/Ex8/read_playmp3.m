[y,Fs] = audioread('ELECTRIC_GUITAR1.mp3');
%Play the audio.

sound(y,Fs)
%Info about file: samples, duration, bitrate etc...
info = audioinfo('ELECTRIC_GUITAR1.mp3')

%Plot the audio data as a function of time.
plot(y)
xlabel('Time')
ylabel('Audio Signal')
