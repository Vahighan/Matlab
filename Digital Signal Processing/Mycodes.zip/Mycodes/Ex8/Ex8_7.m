% Details of (Infinite Impulse Response) digital filter design via bilinear transformation)
clear all; close all;

% Digital requirements
fs = 500;     % sampling ratio
f1 = 400;     % minimum frequency of band-pass filter
f2 = 600;     % maximum frequency of band-pass filter
N  = 8;       % number of poles

% Analog requirements --> digital requirements
f1 = 2*fs*tan(pi*f1/fs) / (2*pi);     % f1: analog --> digital 
f2 = 2*fs*tan(pi*f2/fs) / (2*pi);     % f2: analog --> gigital
w0 = 2*pi*sqrt(f1*f2);                % center of the pass-band 
dw = 2*pi*(f2-f1);                    % width of the pass-band

% Analog filter design (using different low-pass prototypes)
[z,p,gain] = cheb2ap(N,100);               % low-pass Chebyshev 2 prototype filter
%[z,p,gain] = lp2bp(z,p,w0,dw);            % frequency transformation: LP to BP
b = real(gain.*poly(z)); a = real(poly(p)); % analog zeros&poles --> [b,a] coeffs
f = 0 : fs/2000 : fs;                      % frequencies of interest
H = freqs(b,a,2*pi*f);                     % frequency response of analog filter
figure; plot(f,20*log10(abs(H))); xlabel('f (Hz)'); title('Analog |H(f)| (dB)'); 
figure; plot(f,unwrap(angle(H))); xlabel('f [Hz]'); title('angle(H(f)) [rad]'); grid;
% Conversion of analog filter to digital
[z,p,gain] = bilinear(z,p,gain,fs);      % bilinear transformation
b = real(gain*poly(z)); a = real(poly(p)); % analog zeros&poles --> [b,a] coeffs
fvtool(b,a),                          % displaying digital filter frequency response

% Add plot of zeros & poles
% Calculate and display yourself filter frequency response, without H=freqz(b,a,...)
% Do filtration of some signals, without y=filter(b,a,x)
figure;
v=0:pi/1000:2*pi; c=cos(v); s=sin(v);
plot(real(z),imag(z),'bo', real(p),imag(p),'r*',c,s,'k-'); grid;
title('Zeros and Poles'); xlabel('Real()'); ylabel('Imag()');

Nx = 1000; % number of samples
dt = 1/fs; t = dt*(0:Nx-1); % sampling times
%x = zeros(1,Nx); x(1) = 1; % Kronecker delta impulse
x = sin(2*pi*20*t+pi/3) + sin(2*pi*500*t+pi/7); % sum of 2 sines -> passing the 20Hz frequency and 500Hz
% Digital IIR filtration: x(n) --> [ b, a ] --> y(n)
% y=filter(b,a,x); % all-in-one Matlab function
M = length(b); % number of {b} coefficients
N = length(a); a = a(2:N); N=N-1; % number of {a} coeffs, remove a0=1
bx = zeros(1,M); % buffer for input samples x(n)
by = zeros(1,N); % buffer for output samples y(n)
for n = 1 : Nx % MAIN LOOP
bx = [ x(n) bx(1:M-1) ]; % put new x(n) into bx buffer
y(n) = sum( bx .* b ) - sum( by .* a ); % do filtration, find y(n)
by = [ y(n) by(1:N-1) ]; % put y(n) into by buffer
end
% FIGURES: comparison of input and output
figure;
subplot(211); plot(t,x); title('x(t)'); grid; % input signal x(t)

subplot(212); plot(t,y); title('y(t)'); grid; % output signal y(t)


xlabel('t [s]'); 
figure; % signal spectra of the second halves of samples (transients are removed!)
k=Nx/2+1:Nx; f0 = fs/(Nx/2); f=f0*(0:Nx/2-1);
subplot(211); plot(f,20*log10(abs(2*fft(x(k)))/(Nx/2))); title('|X(f)|'); grid;
subplot(212); plot(f,20*log10(abs(2*fft(y(k)))/(Nx/2))); title('|Y(f)|'); grid;
xlabel('f [Hz]'); 