fs=100; Nx=100; % sampling frequency, number of samples
dt = 1/fs; % sampling period
t = dt*(0:Nx-1); % sampling times (many moments)
A1=0.5; f1=1; p1=pi/4; % sine: amplitude, frequency and phase
x1 = A1 * sin(2*pi*f1*t+p1);
[y,Fs] = audioread('ELECTRIC_GUITAR1.mp3');
%Play the audio.

sound(y,Fs)
%Info about file: samples, duration, bitrate etc...
info = audioinfo('ELECTRIC_GUITAR1.mp3')

%Plot the audio data as a function of time.
plot(y)
xlabel('Time')
ylabel('Audio Signal')

resample(y,x1)
y=y+sin(2*pi*f1*t);

sound(y,Fs)
%Info about file: samples, duration, bitrate etc...
info = audioinfo('ELECTRIC_GUITAR1.mp3')

%Plot the audio data as a function of time.
plot(y)
xlabel('Time')
ylabel('Audio Signal')